SENTINEL-X Malware — EMBER/LIEF Compatibility Audit
====================================================
The user's installed ember.features.py was inspected. It uses:
  * lief.bad_format, lief.bad_file, lief.pe_error, lief.parser_error,
    lief.read_out_of_bound in PEFeatureExtractor.raw_features
  * lief.not_found and lief.PE.SECTION_CHARACTERISTICS in SectionInfo
  * numpy.int in ByteEntropyHistogram
  * several LIEF PE object properties used to generate hashed PE features.
The first failure (`lief.bad_format` absent) is not the only potential problem.

Do not blindly monkeypatch LIEF exceptions, replace NumPy aliases, or
upgrade/downgrade libraries inside your active SENTINEL-X environment.
Doing so may produce vectors of the correct shape but a different meaning.

Safe usage from repository root (PowerShell):
  python .\check_ember_compatibility.py --pe C:\Windows\System32\notepad.exe --report .\ember_preflight.json
  # A nonzero exit code is expected with known incompatible dependencies.

Required to promote real malware inference:
  (1) A working separate environment capable of reproducing EMBER-v2
      extraction with LIEF 0.9.0-era behavior (historical stack may require
      an older Python and careful platform compatibility checks).
  (2) A labeled, nonmalicious reference PE and its golden 2381-length vector
      computed with the *same extraction stack used to create training data*.
  (3) Compare vectors and model outputs before accepting an adapter or
      migration; document tolerance per feature (especially hashing and PE
      parsing semantics) and test multiple distinct PE types.
  (4) Keep current malware prediction fail-closed until parity is verified.

This package DOES NOT change model weights or active detection code.
