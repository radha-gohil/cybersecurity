"""Read-only EMBER-v2/LIEF compatibility preflight for SENTINEL-X.

Does not load pickled models, write database records, or execute inspected PE files.
Exit codes: 0 = API checks + vector extraction succeeded (NOT training parity),
            2 = incompatibility or extraction failure, 3 = input error.
"""
from __future__ import annotations
import argparse
import hashlib
import importlib.metadata
import json
import math
import sys
from pathlib import Path

EXPECTED_FEATURES = 2381

def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--pe', type=Path, help='Optional benign Windows PE to inspect')
    ap.add_argument('--report', type=Path, help='Optional report JSON destination')
    args = ap.parse_args()
    result = {'expected_features':EXPECTED_FEATURES, 'classification_performed':False,
              'model_loaded':False, 'production_safe_to_enable':False,
              'training_feature_parity_verified':False, 'problems':[], 'warnings':[]}
    try:
        import numpy as np
        import lief
        import ember.features as ember_features
    except Exception as exc:
        result['problems'].append('Dependency import failure: '+repr(exc))
        return finish(result, args.report, 2)
    for package in ('numpy','lief','ember','scikit-learn'):
        try: result[package+'_version']=importlib.metadata.version(package)
        except importlib.metadata.PackageNotFoundError: result[package+'_version']='NOT INSTALLED'
    result['lief_runtime_version']=getattr(lief,'__version__','UNKNOWN')
    result['ember_source']=str(Path(ember_features.__file__).resolve())
    old_lief_names=('bad_format','bad_file','pe_error','parser_error','read_out_of_bound','not_found')
    result['missing_legacy_lief_symbols']=[name for name in old_lief_names if not hasattr(lief,name)]
    result['missing_legacy_numpy_symbols']=[name for name in ('int',) if not hasattr(np,name)]
    if result['missing_legacy_lief_symbols']:
        result['problems'].append('EMBER-v2 references missing legacy LIEF attributes: '+', '.join(result['missing_legacy_lief_symbols']))
    if result['missing_legacy_numpy_symbols']:
        result['problems'].append('EMBER-v2 references removed NumPy attributes: '+', '.join(result['missing_legacy_numpy_symbols']))
    result['warnings'].append('Passing 2381 features is NOT proof of EMBER training feature parity; a golden vector generated in the training-compatible environment is required.')
    if args.pe is not None:
        path=args.pe
        if not path.is_file():
            result['problems'].append('PE path is not an existing file: '+str(path))
            return finish(result,args.report,3)
        try:
            file_bytes=path.read_bytes()
        except OSError as exc:
            result['problems'].append('Cannot read PE: '+repr(exc))
            return finish(result,args.report,3)
        result['file_sha256']=hashlib.sha256(file_bytes).hexdigest()
        result['file_size']=len(file_bytes)
        if not file_bytes.startswith(b'MZ'):
            result['problems'].append('Input does not have an MZ header.')
        elif result['problems']:
            result['warnings'].append('Skipped PE extraction: incompatible dependencies; no monkeypatch applied.')
        else:
            try:
                extractor=ember_features.PEFeatureExtractor(feature_version=2,print_feature_warning=False)
                vector=np.asarray(extractor.feature_vector(file_bytes),dtype=np.float32)
                result['actual_features']=int(vector.size)
                result['all_finite']=bool(np.isfinite(vector).all())
                if vector.ndim!=1 or vector.size!=EXPECTED_FEATURES or not result['all_finite']:
                    result['problems'].append('Feature vector shape or numerical validity failed.')
            except Exception as exc:
                result['problems'].append('Actual extraction failed: '+repr(exc))
    return finish(result,args.report,2 if result['problems'] else 0)

def finish(result:dict, output:Path|None, code:int)->int:
    result['preflight_status']='BLOCKED' if code else 'API_CHECK_PASSED_PARITY_UNVERIFIED'
    content=json.dumps(result,indent=2,ensure_ascii=False)
    print(content)
    if output:
        output.parent.mkdir(parents=True,exist_ok=True)
        output.write_text(content+'\n',encoding='utf-8')
    return code

if __name__=='__main__':
    sys.exit(main())
